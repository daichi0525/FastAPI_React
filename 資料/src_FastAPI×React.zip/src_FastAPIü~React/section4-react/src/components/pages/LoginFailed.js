import React from "react";

const LoginFailed = () => {
  return <div>ログイン失敗画面</div>;
};

export default LoginFailed;
