import React from "react";

const Register = () => {
  return <div>登録画面</div>;
};

export default Register;
