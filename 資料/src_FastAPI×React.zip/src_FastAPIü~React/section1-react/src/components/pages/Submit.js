import React from "react";
import Form from "../templates/Form";

const Submit = () => {
  return (
    <div>
      <Form />
    </div>
  );
};

export default Submit;
